class mefa_Humanoid_Logic_Base extends ZombieBase
{
    ref Timer m_NavmeshUpdateTimer;
    
    void mefa_Humanoid_Logic_Base()
    {
        // Konstruktor může být prázdný nebo můžete přidat vlastní inicializace
    }

    override void EEInit()
    {
        super.EEInit();
        if (GetGame().IsServer())
        {
            // Zpráva při inicializaci jednotky
            GetGame().ChatPlayer("Unit Initialized and Spawned");
            
            UpdateNavmeshInRadius();  // První aktualizace navmesh
            // Nastavení časovače pro pravidelnou aktualizaci každých 10 sekund
            m_NavmeshUpdateTimer = new Timer(CALL_CATEGORY_SYSTEM);
            m_NavmeshUpdateTimer.Run(10.0, this, "UpdateNavmeshInRadius", null, true);  // Spouští každých 10 sekund
        }
    }

    // Funkce pro kontrolu objektů v okolí a aktualizaci navmesh
    void UpdateNavmeshInRadius()
    {
        float radius = 20.0;  // Radius pro kontrolu objektů kolem zombie
        vector position = this.GetPosition();
        array<Object> nearbyObjects = new array<Object>();
        array<CargoBase> proxyCargos = new array<CargoBase>();

        // Získání objektů v radiusu 20 metrů
        GetGame().GetObjectsAtPosition3D(position, radius, nearbyObjects, proxyCargos);

        // Zpráva pro hráče
        GetGame().ChatPlayer("Checking objects within radius for navmesh update...");

        // Foreach pro objekty v okolí
        for (int i = 0; i < nearbyObjects.Count(); i++)
        {
            Object obj = nearbyObjects.Get(i);
            if (obj.CanAffectPathgraph())
            {
                obj.SetAffectPathgraph(true, false);

                // Naplánování aktualizace navmesh pro objekt s 10 sekundovým zpožděním
                GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(GetGame().UpdatePathgraphRegionByObject, 10, false, obj);

                // Zpráva pro hráče o aktualizaci navmesh pro konkrétní objekt
                GetGame().ChatPlayer("Navmesh updated for object: " + obj.GetType());

                // Regenerace navmesh (zpožděný volání pomocí CallLater)
                GetGame().GetCallQueue(CALL_CATEGORY_GAMEPLAY).CallLater(UpdateNavmesh, 500, false);  // Zpoždění 500ms
            }
        }
    }

    // Funkce pro regeneraci navmesh
    void UpdateNavmesh()
    {
        // Zpráva pro hráče
        GetGame().ChatPlayer("Regenerating navmesh...");

        // Kód pro aktualizaci navmesh
        GetGame().UpdatePathgraphRegionByObject(this);  // Příklad volání pro aktualizaci navmesh
    }

    override bool ResistContaminatedEffect()
    {
        return true;
    }

    override bool CanBeSkinned()
    {
        return false;
    }

    override bool IsHealthVisible()
    {
        return true;
    }

    override void EEHealthLevelChanged(int oldLevel, int newLevel, string zone)
    {
        super.EEHealthLevelChanged(oldLevel, newLevel, zone);
        int currentHealthLevel;
        currentHealthLevel = GetHealthLevel();

        // IF DAMAGING

        // Health <=70% && Health >= 51%
        /*if (oldLevel == GameConstants.STATE_PRISTINE && newLevel == GameConstants.STATE_WORN) {
            GetGame().ChatPlayer("worn - health between 70% and 51%");
        }
        // Health <=50% && Health >= 31%
        if (oldLevel == GameConstants.STATE_WORN && newLevel == GameConstants.STATE_DAMAGED) {
            GetGame().ChatPlayer("moderately damaged - health between 50% and 31%");
        }
        // Health <=30% && Health >= 1%
        if (oldLevel == GameConstants.STATE_DAMAGED && newLevel == GameConstants.STATE_BADLY_DAMAGED) {
            GetGame().ChatPlayer("heavily damaged - health between 30% and 1%");
        }
        // Health <=0% --> DEATH
        // Toto by mělo kontrolovat přechod na STATE_RUINED, ne zpět na STATE_DAMAGED
        if (oldLevel == GameConstants.STATE_BADLY_DAMAGED && newLevel == GameConstants.STATE_RUINED) {
            GetGame().ChatPlayer("ruined - health at 0%");
        }

        // Kontrola, zda je nový stav STATE_RUINED
        if (newLevel == GameConstants.STATE_RUINED) {
            GetGame().ChatPlayer("ruined - health at 0%");
        }*/

    }

    //-------------- NEW COMBAT MECHANIC (METHODS)----------------

    // Weapon DamageTypes
    /*
    DEFAULT = 0;
    SLASH = 1;
    PIERCE = 2;
    SPECIALIST = 3;
    CAVALRY = 4;
    CRUSH = 5;
    SIEGE = 6;
    FLAME = 7;
    FROST = 8;
    MAGIC = 9;
    HERO = 10;
    HERO_RANGED = 11;
    STRUCTURAL = 12;
    POISON = 13;
    */
    float GetEnemyDamageType(ZombieBase zombie)
    {
        return GetGame().ConfigGetFloat("CfgVehicles " + zombie.GetType() + " DamageType");
    }

    float GetEnemyDamageTypItem(ItemBase item)
    {
        return GetGame().ConfigGetFloat("CfgVehicles " + item.GetType() + " DamageType");
    }

    float GetEnemyDamageTypItem2(ItemBase item)
    {
        return GetGame().ConfigGetFloat("CfgVehicles " + item.GetType() + " DamageType2");
    }

    float CalculateAdjustedDamage(TotalDamageResult damageResult, string dmgZone, string armorMultiplierFromConfig, float armorModifier)
    {
        float ArmorMultiplier = GetGame().ConfigGetFloat("CfgVehicles " + this.GetType() + " " + armorMultiplierFromConfig);
        float damage = damageResult.GetDamage(dmgZone, "Health");
        return damage * (ArmorMultiplier - armorModifier);
    }

    void ApplyDamage(string dmgZone, float adjustedDamage)
    {
        float newHealth = this.GetHealth(dmgZone, "Health") - adjustedDamage;
        this.SetHealth(dmgZone, "Health", newHealth);
    }

    void ~mefa_Humanoid_Logic_Base()
    {
        // Zastavení časovače při zničení jednotky
        if (m_NavmeshUpdateTimer)
        {
            m_NavmeshUpdateTimer.Stop();
            m_NavmeshUpdateTimer = null;
        }
    }
}
