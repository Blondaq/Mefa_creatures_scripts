enum CreaturelCmd
{
	WILD,
	PLRCONTROL
}

class mefa_Orc_Warrior_Controlled : mefa_Humanoid_Logic_Base {
	
	private bool m_IsControlled = false;  // Přidána proměnná určující, zda je ork kontrolován
	float armorModifier = 0;
	float adjustedDamage;
	protected PlayerBase m_ControllingPlayer;  // Reference na hráče, který kontroluje orka

	protected int m_CreaturelCmd;
	protected AIAgent m_AIAgent;

	void mefa_Orc_Warrior_Controlled()
	{
		RegisterNetSyncVariableInt("m_CreaturelCmd");
		SetCreaturelCmd(CreaturelCmd.WILD);
	}

	

	void SetControlled(bool state) {
        m_IsControlled = state;
    }

    bool IsControlled() {
        return m_IsControlled;
    }

	 void SetControllingPlayer(PlayerBase player) {
        m_ControllingPlayer = player;
    }

    PlayerBase GetControllingPlayer() {
        return m_ControllingPlayer;
    }

    override void OnRPC(PlayerIdentity sender, int rpc_type, ParamsReadContext ctx) {
        super.OnRPC(sender, rpc_type, ctx);
        // Pro případné další RPC implementace, pokud budete posílat zprávy mezi klientem a serverem
    }

    // Příklad metody odpojení:
    void ResetControl() {
        m_ControllingPlayer = null;  // Odpojení hráče
    }


	override void EOnFrame(IEntity other, float timeSlice)
	{
	if (!GetGame().IsServer()) // Zajištění, že kód běží pouze na serveru
			return;


	// Kontrola, zda je tato creatura označena, a výpis informací
		if (m_ControllingPlayer && this) // Kontrola, zda jsou reference platné
		{
			// Získání aktuální pozice orka
			vector orcPosition = this.GetPosition();
			vector orcOrientation = this.GetOrientation(); // Získání orientace orka

			// Výpočet posunuté pozice hráče (1 metr za orkem)
			float offsetHeight = 0.0; // Výška hráče nad terénem
			float distanceBehind = 0.3; // Posun hráče o 1 metr dozadu

			// Převod orientace na směr (vektor)
			vector direction = Vector(Math.Sin(orcOrientation[0] * Math.DEG2RAD), 0, Math.Cos(orcOrientation[0] * Math.DEG2RAD));
			vector playerPosition = orcPosition + (direction * distanceBehind); // Posun hráče o 1 metr za orka
			playerPosition[1] = orcPosition[1] + offsetHeight; // Nastavení výšky hráče

			// Nastavení hráče na vypočtenou pozici
			m_ControllingPlayer.SetPosition(playerPosition);

			// Simulace "šlapání vody" nebo běhu ve vzduchu
			HumanCommandMove hcm = m_ControllingPlayer.GetCommand_Move();
			if (!hcm) // Pokud hráč právě neprovádí žádnou akci pohybu
			{
				m_ControllingPlayer.StartCommand_Move(); // Zahájení základního pohybu
			}

			// Zajištění, že hráč není ovlivněn fyzikou (např. gravitací nebo kolizemi)
			m_ControllingPlayer.PhysicsEnableGravity(false); // Vypnutí gravitace
			m_ControllingPlayer.COTSetRemoveCollision(true, true); // Deaktivace kolizí
		}


	}


	/*override void EOnFrame(IEntity other, float timeSlice) {
        super.EOnFrame(other, timeSlice);
		Input input = GetGame().GetInput(); // Získání vstupu od hráče
        if (m_IsControlled) 
		{
			if (input.LocalPress("UAFire")) // Například stisknutí levého tlačítka myši
			{
				GetGame().ChatPlayer("Attack");
			}		
        }
		
    }*/

	override bool EEOnDamageCalculated(TotalDamageResult damageResult, int damageType, EntityAI source, int component, string dmgZone, string ammo, vector modelPos, float speedCoef)
	{
		ZombieBase zombie = ZombieBase.Cast(source);
		ItemBase projectile = ItemBase.Cast(source);
		float EnemyDamageType;
		float EnemyDamageTypeItem;
		float EnemyDamageTypeItem2;
		if (projectile) 
		{
			if (projectile.IsKindOf("mefa_Anorien_Archers_Arrow")) {
				{
					this.StartCommand_Hit(true, 0, -25.0);
					EnemyDamageTypeItem = GetEnemyDamageTypItem(projectile);
					if (EnemyDamageTypeItem == 2) //PIERCE
					{
						adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "PIERCE", armorModifier);
						//GetGame().ChatPlayer("PIERCE item adjustedDamage: " + adjustedDamage.ToString());
						ApplyDamage(dmgZone, adjustedDamage);
					}
					//return false;
				}
			}
			else if (projectile.IsKindOf("mefa_Anorien_Archers_Arrow_Fire_Upgrade")) {
				{
					this.StartCommand_Hit(true, 0, -25.0);
					EnemyDamageTypeItem = GetEnemyDamageTypItem(projectile);
					EnemyDamageTypeItem2 = GetEnemyDamageTypItem2(projectile);
					if (EnemyDamageTypeItem == 2) //PIERCE
					{
						adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "PIERCE", armorModifier);
						//GetGame().ChatPlayer("PIERCE item adjustedDamage: " + adjustedDamage.ToString());
						ApplyDamage(dmgZone, adjustedDamage);
					}
					if (EnemyDamageTypeItem2 == 7) //FLAME
					{
						adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "FLAME", armorModifier);
						//GetGame().ChatPlayer("PIERCE item adjustedDamage: " + adjustedDamage.ToString());
						ApplyDamage(dmgZone, adjustedDamage);
					}

					//return false;
				}
			}
		}
			

		else if (zombie)
		{
			EnemyDamageType = GetEnemyDamageType(zombie);
			if (EnemyDamageType == 0) //DEFAULT
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "DEFAULT", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 1) //SLASH
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "SLASH", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 2) //PIERCE
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "PIERCE", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 3) //SPECIALIST
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "SPECIALIST", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 4) //CAVALRY
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "CAVALRY", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 5) //CRUSH
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "CRUSH", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 6) //SIEGE
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "SIEGE", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 7) //FLAME
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "FLAME", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 8) //FROST
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "FROST", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 9) //MAGIC
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "MAGIC", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 10) //HERO
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "HERO", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 11) //HERO_RANGED
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "HERO_RANGED", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 12) //STRUCTURAL
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "STRUCTURAL", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
			else if (EnemyDamageType == 13) //POISON
			{
				adjustedDamage = CalculateAdjustedDamage(damageResult, dmgZone, "POISON", armorModifier);

				ApplyDamage(dmgZone, adjustedDamage);
			}
		}
		

		return false;  // Vr t  false, aby se zabr nilo dal  mu zpracov n  po kozen 
	}

	override void EEHitBy(TotalDamageResult damageResult, int damageType, EntityAI source, int component, string dmgZone, string ammo, vector modelPos, float speedCoef)
	{
		super.EEHitBy(damageResult, damageType, source, component, dmgZone, ammo, modelPos, speedCoef);
		float causedDamageValue;
	
		int objectSize;
		int boneIndex;
		vector localPosition;
		string objectClassName;
		Object objectInstance;
		vector arrowOrientation;
		if (source.GetType() == "mefa_Anorien_Archers_Arrow")
		{
			causedDamageValue = damageResult.GetDamage(dmgZone, "Health");
			// GetGame().ChatPlayer("dmgZone is: " + dmgZone);
		   //  GetGame().ChatPlayer("component is: " + component.ToString());
		   //  GetGame().ChatPlayer("modelPos is: " + modelPos.ToString());
		   //  GetGame().ChatPlayer("damage is: " + causedDamageValue.ToString());





			objectClassName = "mefa_Anorien_Archers_Arrow";
			localPosition = "0 0 0";
			objectSize = 1;
			boneIndex = this.GetBoneIndexByName(dmgZone);
			if (boneIndex != -1) {
				objectInstance = GetGame().CreateObject(objectClassName, this.GetPosition(), false, true, true);

				// Z sk n  orientace   pu
				arrowOrientation = source.GetOrientation();

				objectInstance.SetPosition(localPosition);
				objectInstance.SetOrientation(arrowOrientation);
				this.AddChild(objectInstance, boneIndex);
			}
			else {
				//GetGame().ChatPlayer("Invalid bone: " + dmgZone);
			}

			GetGame().ObjectDelete(source);
		}
		

	}


	override bool FightAttackLogic(int pCurrentCommandID, DayZInfectedInputController pInputController, float pDt)
	{
		//GetGame().ChatPlayer("FightAttackLogic Funguje?");
		m_ActualTarget = pInputController.GetTargetEntity();

		//! do not attack players in vehicle - hotfix
		PlayerBase pb = PlayerBase.Cast(m_ActualTarget);
		if (pb && pb.GetCommand_Vehicle())
			return false;

		if (m_ActualTarget == null || IsTargetAlive(m_ActualTarget) == false)
		{
			ResetTarget();
			return false;
		}

		vector targetPos = m_ActualTarget.GetPosition();
		float targetDist = vector.Distance(targetPos, this.GetPosition());
		int pitch = GetAttackPitch(m_ActualTarget);

		float target_distance = vector.DistanceSq(m_ActualTarget.GetPosition(), GetPosition());
		m_ActualAttackType = GetDayZInfectedType().ChooseAttack(DayZInfectedAttackGroupType.FIGHT, targetDist, pitch);
		{
			// 20stupnu bude uhel toho kuzelu a bude dlouhej 11m
			Object target = DayZPlayerUtils.GetMeleeTarget(this.GetPosition(), this.GetDirection(), 20, 11, -1.0, 2.0, this, m_TargetableObjects, m_AllTargetObjects);

			if (m_AllTargetObjects.Count() > 0 && m_AllTargetObjects[0] != m_ActualTarget)
			{
				m_AllTargetObjects.Clear();
				return false;
			}

			m_ActualAttackType = GetDayZInfectedType().ChooseAttack(DayZInfectedAttackGroupType.CHASE, targetDist, pitch);
			if (targetDist < 1.7)
			{
				//int randomAttackType = Math.RandomIntInclusive(0, 4); // nahodny utok 5 /6  jeste by mel zmrazit hraci kontrol ovladani
				int randomAttackType = 0;
				//GetGame().ChatPlayer("Vybran nahodny utok: " + randomAttackType);   //  0- Default utok //  5- right attack
				StartCommand_Attack(m_ActualTarget, randomAttackType, 0);
				m_AttackCooldownTime = 0.2;
				return true;
			}
			else
			{
				return false;
			}


		}
		return false;
	}
	override bool ChaseAttackLogic(int pCurrentCommandID, DayZInfectedInputController pInputController, float pDt)
	{
		// Aktualizuj cíl
		m_ActualTarget = pInputController.GetTargetEntity();

		// Zkontroluj, zda je hráč v autě (nelze útočit)
		PlayerBase pb = PlayerBase.Cast(m_ActualTarget);
		if (pb && pb.GetCommand_Vehicle())
		{
			GetGame().ChatPlayer("Target is in a vehicle. Cannot attack.");
			return false;
		}

		// Zkontroluj, zda cíl existuje a je živý
		if (!m_ActualTarget || !IsTargetAlive(m_ActualTarget))
		{
			GetGame().ChatPlayer("No valid target or target is not alive.");
			ResetTarget();
			return false;
		}

		vector targetPos = m_ActualTarget.GetPosition();

		// Zkontroluj, zda cíl lze napadnout (dosažitelnost)
		if (!CanAttackToPosition(targetPos))
		{
			GetGame().ChatPlayer("Target is not in attackable position.");
			return false;
		}

		// Vypočítej vzdálenost a sklon útoku
		float targetDist = vector.Distance(targetPos, this.GetPosition());
		int pitch = GetAttackPitch(m_ActualTarget);

		// Zvol útok na základě vzdálenosti a sklonu
		m_ActualAttackType = GetDayZInfectedType().ChooseAttack(DayZInfectedAttackGroupType.CHASE, targetDist, pitch);

		// Zkontroluj vzdálenost pro útok
		if (targetDist < 1.5) // Velmi blízký útok (např. běh)
		{
			GetGame().ChatPlayer("Performing close-range attack.");
			if (StartCommand_Attack(m_ActualTarget, 5, 0)) // Typ útoku 5 (nebo jiný dle logiky)
			{
				m_AttackCooldownTime = 0.2; // Cooldown mezi útoky
				return true;
			}
			else
			{
				GetGame().ChatPlayer("Failed to start close-range attack animation.");
				return false;
			}
		}
		else if (targetDist < 3.0) // Střední vzdálenost (neútočí, ale sleduje)
		{
			GetGame().ChatPlayer("Target is within medium range, preparing for attack.");
			return true; // Neútočí, ale je připraven
		}

		// Pokud není splněna žádná podmínka
		GetGame().ChatPlayer("Target is too far for an attack.");
		return false;
	}

	bool IsCreatureAlive()
	{
		if(this.GetHealth() > 0)
		{
			return false;
		}
		else
		{
			return false;
		}

	}


	bool IsTargetAlive(EntityAI target)
	{
		if (target)
		{
			return target.GetHealth() > 0;
		}
		return false;
	}


	void ResetTarget()
	{
		
		m_ActualTarget = null;
		
	}


protected float m_AutoAttackDisableTimer = 0.0;  // Časovač pro zpoždění autoattacku po pohybu
protected const float AUTOATTACK_DISABLE_COOLDOWN = 2.0;  // Délka cooldownu po pohybu v sekundách
	
override bool ModCommandHandlerAfter(float pDt, int pCurrentCommandID, bool pCurrentCommandFinished)
{
    if (super.ModCommandHandlerAfter(pDt, pCurrentCommandID, pCurrentCommandFinished))
    {
        return true;
    }
    if (GetGame().IsClient() || !GetGame().IsMultiplayer())
    {
        return true;
    }
	
    DayZInfectedInputController inputController = this.GetInputController();

    if (m_IsControlled) {
        SetCreaturelCmd(CreaturelCmd.PLRCONTROL);
    }
    else
    {
        SetCreaturelCmd(CreaturelCmd.WILD);
    }

     m_AIAgent = this.GetAIAgent();
    m_AIAgent.SetKeepInIdle(true); 
    PlayerBase player = GetControllingPlayer();
    float plrspeed = 0.0;   // Rychlost hráče
    vector plrdirection;    // Směr pohybu

    if (player == null)
    {
        return false;  // Ukonči, pokud není hráč připojen
    }

	vector playerPos = player.GetPosition();
    vector orcPos = this.GetPosition();
    float distance = vector.Distance(playerPos, orcPos);

	HumanInputController hic = player.GetInputController();
	if (hic == null)
	{
		//GetGame().ChatPlayer("Error: HumanInputController is null.");
		return false;  // Ukonči, pokud neexistuje HumanInputController
	}

	 // Snížení časovače cooldownu
    if (m_AutoAttackDisableTimer > 0.0)
    {
        m_AutoAttackDisableTimer -= pDt;
    }

    if (this.GetCreaturelCmd() == CreaturelCmd.PLRCONTROL)
    {
       	if (this.GetCommand_Move() == null && plrdirection.Length() > 0.1)
		{
			this.StartCommand_Move();
		}

        if (plrdirection.Length() > 0.1)  // Kontrola pohybu hráče
        {
           // GetGame().ChatPlayer("Player is moving, autoattack interrupted.");
            ResetAutoAttack();  // Přeruší autoattack, pokud hráč běží
            m_AutoAttackDisableTimer = AUTOATTACK_DISABLE_COOLDOWN;  // Nastav cooldown
        }

        // Pokud cooldown ještě nevypršel, neprováděj autoattack
        if (m_AutoAttackDisableTimer > 0.0)
        {
           // GetGame().ChatPlayer("Autoattack on cooldown, waiting...");
            return true;
        }

        // Spusť autoattack logiku
        AutoAttack(pDt);

        // Pohyb během autoattacku
        HandleMovementDuringAutoAttack(pDt, hic);

        return true;
    }
    return false;

}

bool HandleMovementDuringAutoAttack(float pDt, HumanInputController hic)
{
    float plrspeed = 0.0;  // Rychlost hráče
    vector plrdirection;   // Směr pohybu

    DayZInfectedInputController inputController = this.GetInputController();
    hic.GetMovement(plrspeed, plrdirection);  // Získání rychlosti a směru pohybu

    vector currentOrientation = this.GetOrientation();
    float rotationSpeed = 150.0;  // Čím vyšší hodnota, tím rychlejší rotace
    float targetYaw = currentOrientation[0];  // Počáteční yaw úhel
	if (plrdirection.Length() > 0.1)  // Pokud hráč vydá pohybový příkaz
    {
       	if (this.GetCommand_Move() == null && plrdirection.Length() > 0.1)
		{
			this.StartCommand_Move();
		}

    }
     if (plrdirection[2] > 0)  // Pohyb dopředu
    {
        if (plrdirection[0] < 0)
        {
             targetYaw -= rotationSpeed * pDt * 5.0;  // Plynulá rotace vlevo
            inputController.OverrideMovementSpeed(true, 2.0);  
        }
        else if (plrdirection[0] > 0)
        {
            targetYaw += rotationSpeed * pDt * 5.0;  // Plynulá rotace vpravo
            inputController.OverrideMovementSpeed(true, 2.0);  
        }
        else
        {
            inputController.OverrideMovementSpeed(true, 2.0);  
        }
    }
    else if (plrdirection[2] < 0)  // Pohyb dozadu
    {
        inputController.OverrideMovementSpeed(true, 0);
        return true;
    }
    else  // Pokud se hráč jen otáčí na místě
    {
        if (plrdirection[0] < 0)  // Otočení vlevo
        {
            targetYaw -= rotationSpeed * pDt * 5.0;  // Plynulá rotace vlevo
        }
        else if (plrdirection[0] > 0)  // Otočení vpravo
        {
           targetYaw += rotationSpeed * pDt * 5.0;  // Plynulá rotace vpravo
        }
        else
        {
            inputController.OverrideMovementSpeed(true, 0);
            return true;  // Zůstává v aktuální orientaci
        }
    }

    // Plynulá interpolace yaw úhlu podobná free kameře
    float interpolatedYaw = Math.Lerp(currentOrientation[0], targetYaw, pDt * 9.0);  // Pomalejší přiblížení
    vector newOrientation = Vector(interpolatedYaw, currentOrientation[1], currentOrientation[2]);
    this.SetOrientation(newOrientation);  // Nastavení nové orientace

    return true;
}




protected bool m_IsAutoAttacking = false;  // Příznak automatického útoku
protected float m_AutoAttackCooldown = 1.0;  // Cooldown po útoku
protected float m_AutoAttackTimer = 0.0;  // Časovač pro sledování útoku

// Automatický útok
void AutoAttack(float pDt)
{
	 DayZInfectedInputController inputController = this.GetInputController();
    if (m_AutoAttackTimer > 0.0)
    {
        m_AutoAttackTimer -= pDt;
        return;  // Počkej, dokud cooldown nevyprší
    }

    //GetGame().ChatPlayer("Checking for autoattack target...");

    EntityAI target = FindNearestTarget(10.0);  // Najdi cíl v dosahu 10 metrů

    if (target && IsTargetAlive(target))
    {
       // GetGame().ChatPlayer("Target found: " + target.GetType());
        float distance = vector.Distance(this.GetPosition(), target.GetPosition());

        if (distance < 2.0)  // Blízkost cíle
        {
            if (!m_IsAutoAttacking)
            { 	
                m_IsAutoAttacking = true;  // Nastav příznak autoattacku
			
                GetGame().ChatPlayer("Auto-attacking target: " + target.GetType());
                this.StartCommand_Attack(target, 0, 0);  // Náhodný typ útoku
                m_AutoAttackTimer = m_AutoAttackCooldown;  // Nastav cooldown po útoku
            }
        }
        else
        {
          //  GetGame().ChatPlayer("Target is out of melee range.");
            ResetAutoAttack();  // Reset, pokud je cíl mimo dosah
        }
    }
    else
    {
        ResetAutoAttack();  // Reset, pokud není žádný cíl
       // GetGame().ChatPlayer("No target found.");
    }
}

// Reset autoattacku
void ResetAutoAttack()
{
    m_IsAutoAttacking = false;  // Vypni autoattack
    m_AutoAttackTimer = 0.0;  // Resetuj časovač
}



// Najdi nejbližší cíl v dosahu (pouze ZombieBase nebo AnimalBase)
EntityAI FindNearestTarget(float maxDistance)
{
    array<Object> objectsInRadius = new array<Object>();
    GetGame().GetObjectsAtPosition3D(this.GetPosition(), maxDistance, objectsInRadius, null);

    EntityAI nearestTarget = null;
    float nearestDistance = maxDistance;

    foreach (Object obj : objectsInRadius)
    {
        if (obj == this)
        {
            continue;  // Přeskoč sebe sama
        }

        // Zkontroluj, zda objekt dědí ze ZombieBase nebo AnimalBase
        ZombieBase zombie = ZombieBase.Cast(obj);
        AnimalBase animal = AnimalBase.Cast(obj);

        if (zombie || animal)
        {
            float distance = vector.Distance(this.GetPosition(), obj.GetPosition());
            if (distance < nearestDistance)
            {
                nearestTarget = EntityAI.Cast(obj);
                nearestDistance = distance;
            }
        }
    }

    return nearestTarget;  // Vrať nejbližší cíl nebo null, pokud nebyl nalezen
}







	void SetCreaturelCmd(int creatureCmd)
	{
		m_CreaturelCmd = creatureCmd;
		SetSynchDirty();
	}
	
	int GetCreaturelCmd()
	{
		return m_CreaturelCmd;
	}

	override void OnVariablesSynchronized()
    {
        super.OnVariablesSynchronized();
    }
	





	PlayerBase GetServerPlayer()
	{
		array<Man> players = new array<Man>();
		GetGame().GetPlayers(players);  // Naplní seznam připojených hráčů

		foreach (Man player : players)
		{
			PlayerBase pb = PlayerBase.Cast(player);
			if (pb)  // Pokud hráč existuje
			{
				// Můžeš zde přidat další logiku (např. výběr konkrétního hráče)
				return pb;  // Vrať hráče
			}
		}

		return null;  // Pokud není žádný hráč nalezen
	}

























	void ~mefa_Orc_Warrior_Controlled()
    {
         m_IsControlled = false;  // Odpojení orka při destrukci objektu
    }

	
	
}